a = input('Answer: ').strip().lower()

if a == "42" or a == "forty-two" or a == "forty two":
    print('Yes')
else:
    print('No')