from emoji import emojize

print('Output: ' + emojize(input('Input: '), language='alias'))